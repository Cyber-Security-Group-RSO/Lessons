def add(x, y):
    return x+y

if __name__ == '__main__':
    x = 10
    y = 20
    print(add(x,y))