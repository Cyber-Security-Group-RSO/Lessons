import random

def myfunc():
    x = random.randint(0,1)
    if x == 0:
        print("596f75206c6f7374")
    else:
        print("596f7520576f6e2120466c61673a204353477b64656275677d")

if __name__ == '__main__':
    while True:
        print("Hit Enter")
        x = input()
        myfunc()